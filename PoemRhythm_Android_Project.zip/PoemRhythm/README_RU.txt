POEMRHYTHM: исходники приложения
================================

Внутри:
- www/index.html — готовое приложение (HTML + CSS + JavaScript)
- package.json и capacitor.config.json — настройки оболочки Android на Capacitor

Как получить APK на компьютере:
1. Установи Node.js LTS и Android Studio.
2. Распакуй архив.
3. Открой терминал в папке PoemRhythm и выполни:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
4. В Android Studio дождись завершения Gradle Sync.
5. Выбери Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio покажет расположение готового APK.

Важно:
- Этот архив содержит исходный проект, а не уже собранный APK.
- Для сборки APK нужен Android SDK/Android Studio.
- Ритм-модуль Tone.js и шрифты загружаются из интернета.
- Стихи хранятся локально в браузерном хранилище приложения на устройстве.
